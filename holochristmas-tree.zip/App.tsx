import React, { useState, useEffect, useRef } from 'react';
import ThreeScene from './components/ThreeScene';
import UIControls from './components/UIControls';
import HandTracker from './components/HandTracker';
import { AppState, GestureType, HandData, ParticleShape } from './types';
import { COLORS, YOUTUBE_VIDEO_ID, PHOTO_URLS } from './constants';

const App: React.FC = () => {
  // App State
  const [appState, setAppState] = useState<AppState>({
    particleShape: ParticleShape.SPARKLE,
    particleColor: COLORS.primary,
    isMusicPlaying: false,
    gesture: GestureType.NONE,
    isFullscreen: false,
    photoUrls: PHOTO_URLS // Initialize with default paths
  });

  // Hand Data (lifted up from Tracker to Scene)
  const [handData, setHandData] = useState<HandData | null>(null);

  // YouTube Iframe Ref
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    // Control YouTube Player via postMessage
    if (iframeRef.current && iframeRef.current.contentWindow) {
        const action = appState.isMusicPlaying ? 'playVideo' : 'pauseVideo';
        iframeRef.current.contentWindow.postMessage(
            JSON.stringify({ event: 'command', func: action, args: [] }), 
            '*'
        );
    }
  }, [appState.isMusicPlaying]);

  const handleHandUpdate = (data: HandData | null) => {
    setHandData(data);
    if (data) {
        // Sync detected gesture to UI state for visualization
        if (data.gesture !== appState.gesture) {
            setAppState(prev => ({ ...prev, gesture: data.gesture }));
        }
    } else {
        if (appState.gesture !== GestureType.NONE) {
            setAppState(prev => ({ ...prev, gesture: GestureType.NONE }));
        }
    }
  };

  const handlePhotoUpload = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    
    // Create Blob URLs for the uploaded files
    const newUrls: string[] = [];
    // Take up to 5 files
    const limit = Math.min(files.length, 5);
    for (let i = 0; i < limit; i++) {
        const file = files[i];
        if (file.type.startsWith('image/')) {
            newUrls.push(URL.createObjectURL(file));
        }
    }

    if (newUrls.length > 0) {
        // If user selects less than 5, we keep the old ones or just fill what we have.
        // Let's replace entirely to be clean.
        setAppState(prev => ({ ...prev, photoUrls: newUrls }));
    }
  };

  return (
    <div className="relative w-full h-screen overflow-hidden text-white select-none">
      
      {/* 3D Scene Layer */}
      <ThreeScene handData={handData} appState={appState} />

      {/* UI Controls Layer */}
      <UIControls 
        appState={appState} 
        setAppState={setAppState} 
        handGesture={appState.gesture}
        onPhotoUpload={handlePhotoUpload}
      />

      {/* Hand Tracking Layer (Camera Preview) */}
      <HandTracker onHandUpdate={handleHandUpdate} />

      {/* Christmas Text Overlay */}
      <div className="absolute bottom-6 left-0 right-0 text-center pointer-events-none z-10">
        <h1 className="text-4xl md:text-6xl font-['Great_Vibes'] text-transparent bg-clip-text bg-gradient-to-b from-white via-gray-200 to-gray-400 drop-shadow-[0_0_10px_rgba(255,255,255,0.8)] opacity-90 py-4 leading-relaxed">
          Merry Christmas
        </h1>
      </div>

      {/* Hidden YouTube Player */}
      <div className="hidden">
        <iframe 
            ref={iframeRef}
            id="yt-player"
            width="560" 
            height="315" 
            src={`https://www.youtube.com/embed/${YOUTUBE_VIDEO_ID}?enablejsapi=1&controls=0&loop=1&playlist=${YOUTUBE_VIDEO_ID}&start=8`} 
            title="Background Music" 
            allow="autoplay; encrypted-media"
        />
      </div>

    </div>
  );
};

export default App;