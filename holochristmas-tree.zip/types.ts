export enum ParticleShape {
  SNOWFLAKE = 'SNOWFLAKE',
  HEX_SNOWFLAKE = 'HEX_SNOWFLAKE',
  HEART = 'HEART',
  STAR = 'STAR',
  SPARKLE = 'SPARKLE',
  CIRCLE = 'CIRCLE',
  GIFT_BOX = 'GIFT_BOX'
}

export enum GestureType {
  NONE = 'NONE',
  FIST = 'FIST (Contract)',
  OPEN_PALM = 'OPEN (Bloom)',
  PINCH = 'PINCH (Focus)',
  ROTATE = 'ROTATE'
}

export interface AppState {
  particleShape: ParticleShape;
  particleColor: string; // Hex
  isMusicPlaying: boolean;
  gesture: GestureType;
  isFullscreen: boolean;
  photoUrls: string[]; // Dynamic list of photo URLs
}

export interface HandData {
  gesture: GestureType;
  x: number; // -1 to 1 (screen space)
  y: number; // -1 to 1
  pinchDistance: number; // 0 to 1
  rotation: number; // approximate hand rotation
}