export const COLORS = {
  primary: '#8A2BE2', // BlueViolet
  secondary: '#C0C0C0', // Silver
  highlight: '#FFFFFF',
  bgGradientStart: '#0f172a', // Slate 900
  bgGradientEnd: '#000000',
};

export const PARTICLE_COUNT = 3000;
export const TREE_HEIGHT = 40;
export const TREE_RADIUS = 15;
export const PHOTO_COUNT = 5;

// Default file paths. 
// If you don't use the "Upload" button in the UI, the app will look for these files.
export const PHOTO_URLS = [
  "photos/1.jpg", 
  "photos/2.jpg",
  "photos/3.jpg",
  "photos/4.jpg",
  "photos/5.jpg" 
];

// YouTube Background Music ID (Christmas Jazz)
export const YOUTUBE_VIDEO_ID = "lP7inavqxrU";