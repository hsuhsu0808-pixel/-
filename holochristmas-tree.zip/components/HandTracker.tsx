import React, { useEffect, useRef, useState } from 'react';
// @ts-ignore
import * as mpHands from '@mediapipe/hands';
import { GestureType, HandData } from '../types';
import { ScanFace } from 'lucide-react';

// Handle ESM export structure differences (default vs named) to fix SyntaxError
const Hands = (mpHands as any).Hands || (mpHands as any).default?.Hands;
type Results = any; // Bypass type import issues for the interface at runtime

interface Props {
  onHandUpdate: (data: HandData | null) => void;
}

const HandTracker: React.FC<Props> = ({ onHandUpdate }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [loading, setLoading] = useState(true);
  const requestRef = useRef<number>(0);

  // Helper to calculate distance between two landmarks
  const distance = (p1: any, p2: any) => {
    return Math.sqrt(Math.pow(p1.x - p2.x, 2) + Math.pow(p1.y - p2.y, 2));
  };

  const detectGesture = (landmarks: any[]): { type: GestureType; pinch: number; rotation: number } => {
    const thumbTip = landmarks[4];
    const indexTip = landmarks[8];
    const middleTip = landmarks[12];
    const ringTip = landmarks[16];
    const pinkyTip = landmarks[20];
    const wrist = landmarks[0];
    
    // 1. Pinch Detection (Thumb tip near Index tip)
    const pinchDist = distance(thumbTip, indexTip);
    const isPinch = pinchDist < 0.05;

    // 2. Fist Detection
    const palmCenter = landmarks[9];
    const tips = [indexTip, middleTip, ringTip, pinkyTip];
    const closedCount = tips.filter(t => distance(t, palmCenter) < 0.1).length;
    
    // 3. Open Hand
    const openCount = tips.filter(t => distance(t, palmCenter) > 0.15).length;

    let gesture = GestureType.NONE;

    if (isPinch && openCount > 2) {
      gesture = GestureType.PINCH;
    } else if (closedCount >= 3) {
      gesture = GestureType.FIST;
    } else if (openCount >= 4) {
      gesture = GestureType.OPEN_PALM;
    }

    // Rotation heuristic
    const handRotation = (wrist.x - middleTip.x) * 10;

    return { type: gesture, pinch: pinchDist, rotation: handRotation };
  };

  useEffect(() => {
    if (!videoRef.current || !canvasRef.current) return;

    let active = true;
    let hands: any = null;

    const initializeHands = async () => {
        if (!Hands) {
            console.error("MediaPipe Hands module failed to load. Check imports.");
            setLoading(false);
            return;
        }

        try {
            hands = new Hands({
                locateFile: (file: string) => {
                    return `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`;
                },
            });

            hands.setOptions({
                maxNumHands: 1,
                modelComplexity: 1,
                minDetectionConfidence: 0.5,
                minTrackingConfidence: 0.5,
            });

            hands.onResults((results: Results) => {
                if (!active) return;
                setLoading(false);
                
                const ctx = canvasRef.current?.getContext('2d');
                if (!ctx || !canvasRef.current) return;

                ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
                
                if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
                    const landmarks = results.multiHandLandmarks[0];
                    
                    // Draw debug skeleton
                    ctx.strokeStyle = '#00FF00';
                    ctx.lineWidth = 2;
                    ctx.beginPath();
                    for(let i=0; i<landmarks.length; i++) {
                        const x = landmarks[i].x * canvasRef.current.width;
                        const y = landmarks[i].y * canvasRef.current.height;
                        if(i===0) ctx.moveTo(x, y);
                        else ctx.lineTo(x, y);
                        ctx.fillStyle = 'red';
                        ctx.fillRect(x-2, y-2, 4, 4);
                    }
                    ctx.stroke();

                    const { type, pinch, rotation } = detectGesture(landmarks);
                    
                    const normX = (landmarks[9].x - 0.5) * 2; 
                    const normY = -(landmarks[9].y - 0.5) * 2; 

                    onHandUpdate({
                    gesture: type,
                    x: normX,
                    y: normY,
                    pinchDistance: pinch,
                    rotation: rotation
                    });
                } else {
                    onHandUpdate(null);
                }
            });
        } catch (e) {
            console.error("Failed to initialize MediaPipe Hands", e);
        }
    };

    initializeHands();

    // Custom Camera Loop
    const processVideo = async () => {
      if (!active) return;
      if (videoRef.current && videoRef.current.readyState >= 2 && hands) {
          try {
            await hands.send({ image: videoRef.current });
          } catch (e) {
            // throttle errors
          }
      }
      if (active) {
        requestRef.current = requestAnimationFrame(processVideo);
      }
    };

    const startCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            width: 320,
            height: 240,
            facingMode: 'user'
          }
        });
        
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.onloadedmetadata = () => {
             videoRef.current?.play();
             requestRef.current = requestAnimationFrame(processVideo);
          };
        }
      } catch (err) {
        console.error("Failed to start camera", err);
        setLoading(false);
      }
    };

    startCamera();

    return () => {
      active = false;
      cancelAnimationFrame(requestRef.current);
      if (hands) hands.close();
      if (videoRef.current && videoRef.current.srcObject) {
         const stream = videoRef.current.srcObject as MediaStream;
         stream.getTracks().forEach(track => track.stop());
      }
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="absolute bottom-4 right-4 w-32 h-24 bg-black/50 rounded-lg overflow-hidden border border-white/20 z-10 shadow-lg backdrop-blur-sm group">
      <video
        ref={videoRef}
        className="hidden"
        playsInline
      />
      <canvas
        ref={canvasRef}
        className="w-full h-full object-cover transform -scale-x-100" // Mirror effect
        width={320}
        height={240}
      />
      {loading && (
        <div className="absolute inset-0 flex items-center justify-center text-white/70 text-xs">
          <ScanFace className="animate-pulse w-6 h-6" />
        </div>
      )}
      <div className="absolute bottom-0 w-full bg-black/60 text-[10px] text-center text-white py-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
        Camera Debug
      </div>
    </div>
  );
};

export default HandTracker;