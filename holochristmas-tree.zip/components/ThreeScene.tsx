import React, { useEffect, useRef, useMemo } from 'react';
import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass';
import { HandData, ParticleShape, GestureType, AppState } from '../types';
import { createParticleTexture } from '../utils/textureGenerator';
import { PARTICLE_COUNT, TREE_HEIGHT, TREE_RADIUS, PHOTO_COUNT } from '../constants';

interface Props {
  handData: HandData | null;
  appState: AppState;
}

const ThreeScene: React.FC<Props> = ({ handData, appState }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const particlesRef = useRef<THREE.Points | null>(null);
  const snowRef = useRef<THREE.Points | null>(null);
  const lightsRef = useRef<THREE.Points | null>(null);
  const giftRef = useRef<THREE.Points | null>(null);
  const hexRef = useRef<THREE.Points | null>(null);
  const photosRef = useRef<THREE.Group | null>(null);
  const starRef = useRef<THREE.Mesh | null>(null);
  const ribbonRef = useRef<THREE.Mesh | null>(null);
  const composerRef = useRef<EffectComposer | null>(null);
  
  // Animation state refs for smooth transitions
  const targetScaleRef = useRef(1);
  const rotationSpeedRef = useRef(0.002);
  const particleMaterialRef = useRef<THREE.PointsMaterial | null>(null);

  // Initialize Scene (Static & Particles)
  useEffect(() => {
    if (!containerRef.current) return;

    // 1. Scene & Camera
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    
    // Add fog for depth
    scene.fog = new THREE.FogExp2(0x050510, 0.015);

    const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(0, 0, 80);
    camera.lookAt(0, 0, 0);
    cameraRef.current = camera;

    // 2. Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.toneMapping = THREE.ReinhardToneMapping;
    renderer.outputColorSpace = THREE.SRGBColorSpace; 
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // 3. Post Processing (Bloom)
    const renderScene = new RenderPass(scene, camera);
    const bloomPass = new UnrealBloomPass(new THREE.Vector2(window.innerWidth, window.innerHeight), 1.5, 0.4, 0.85);
    bloomPass.threshold = 0.2; 
    bloomPass.strength = 1.2; 
    bloomPass.radius = 0.5;

    const composer = new EffectComposer(renderer);
    composer.addPass(renderScene);
    composer.addPass(bloomPass);
    composerRef.current = composer;

    // 4. Particles (Tree)
    const geometry = new THREE.BufferGeometry();
    const positions = [];
    const colors = [];
    const sizes = [];
    const randoms = [];

    const colorObj = new THREE.Color(appState.particleColor);

    for (let i = 0; i < PARTICLE_COUNT; i++) {
      const y = Math.random() * TREE_HEIGHT;
      const progress = 1 - (y / TREE_HEIGHT);
      const radius = progress * TREE_RADIUS;
      const angle = y * 10 + Math.random() * Math.PI * 2;
      const x = Math.cos(angle) * radius;
      const z = Math.sin(angle) * radius;

      positions.push(x, y - TREE_HEIGHT / 2, z);
      const mixedColor = colorObj.clone().lerp(new THREE.Color(0xffffff), Math.random() * 0.3);
      colors.push(mixedColor.r, mixedColor.g, mixedColor.b);
      sizes.push(Math.random() * 0.5 + 0.1);
      randoms.push(Math.random());
    }

    geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    geometry.setAttribute('size', new THREE.Float32BufferAttribute(sizes, 1));
    geometry.setAttribute('aRandom', new THREE.Float32BufferAttribute(randoms, 1));
    geometry.userData = { originalPositions: positions };

    const material = new THREE.PointsMaterial({
      size: 0.8,
      vertexColors: true,
      map: createParticleTexture(appState.particleShape),
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      transparent: true,
      opacity: 0.8
    });
    particleMaterialRef.current = material;

    const particles = new THREE.Points(geometry, material);
    scene.add(particles);
    particlesRef.current = particles;

    // 5. Decorations
    // ... (Snow, Lights, Gifts, Hex) ...
    
    // Snow
    const snowGeo = new THREE.BufferGeometry();
    const snowPos = [];
    const snowDriftSpeed = [];
    for(let i=0; i<500; i++) {
        snowPos.push((Math.random() - 0.5) * 80, (Math.random() - 0.5) * 80, (Math.random() - 0.5) * 80);
        snowDriftSpeed.push(Math.random() * 0.02 + 0.01);
    }
    snowGeo.setAttribute('position', new THREE.Float32BufferAttribute(snowPos, 3));
    snowGeo.setAttribute('driftSpeed', new THREE.Float32BufferAttribute(snowDriftSpeed, 1));
    const snow = new THREE.Points(snowGeo, new THREE.PointsMaterial({
        size: 0.8, color: 0xffffff, map: createParticleTexture(ParticleShape.SNOWFLAKE), transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending, depthWrite: false
    }));
    scene.add(snow);
    snowRef.current = snow;

    // Lights
    const lightsGeo = new THREE.BufferGeometry();
    const lightsPos = [];
    for(let i=0; i<200; i++) {
        const p = i / 200;
        const y = THREE.MathUtils.lerp(-TREE_HEIGHT/2, TREE_HEIGHT/2, p);
        const r = THREE.MathUtils.lerp(TREE_RADIUS + 0.5, 0.5, p);
        const a = p * Math.PI * 2 * 8;
        lightsPos.push(Math.cos(a) * r, y, Math.sin(a) * r);
    }
    lightsGeo.setAttribute('position', new THREE.Float32BufferAttribute(lightsPos, 3));
    lightsGeo.userData = { originalPositions: lightsPos };
    const lights = new THREE.Points(lightsGeo, new THREE.PointsMaterial({
        size: 1.2, color: 0xffdd88, map: createParticleTexture(ParticleShape.CIRCLE), transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false
    }));
    scene.add(lights);
    lightsRef.current = lights;

    // Gifts
    const giftGeo = new THREE.BufferGeometry();
    const giftPos = [];
    const giftColors = [];
    for(let i=0; i<35; i++) {
        const y = Math.random() * (TREE_HEIGHT - 4) - TREE_HEIGHT/2 + 2; 
        const r = (1 - ((y + TREE_HEIGHT/2) / TREE_HEIGHT)) * TREE_RADIUS * (0.8 + Math.random() * 0.2); 
        const angle = Math.random() * Math.PI * 2;
        giftPos.push(Math.cos(angle) * r, y, Math.sin(angle) * r);
        const col = new THREE.Color();
        const rand = Math.random();
        if(rand < 0.33) col.setHex(0xFF3333); else if(rand < 0.66) col.setHex(0xFFD700); else col.setHex(0x22FFFF);
        giftColors.push(col.r, col.g, col.b);
    }
    giftGeo.setAttribute('position', new THREE.Float32BufferAttribute(giftPos, 3));
    giftGeo.setAttribute('color', new THREE.Float32BufferAttribute(giftColors, 3));
    giftGeo.userData = { originalPositions: [...giftPos] };
    const gifts = new THREE.Points(giftGeo, new THREE.PointsMaterial({
        size: 2.5, vertexColors: true, map: createParticleTexture(ParticleShape.GIFT_BOX), transparent: true, opacity: 1.0, blending: THREE.NormalBlending, depthWrite: false,
    }));
    scene.add(gifts);
    giftRef.current = gifts;

    // Hex
    const hexGeo = new THREE.BufferGeometry();
    const hexPos = [];
    for(let i=0; i<35; i++) {
        const y = Math.random() * (TREE_HEIGHT - 4) - TREE_HEIGHT/2 + 2;
        const r = (1 - ((y + TREE_HEIGHT/2) / TREE_HEIGHT)) * TREE_RADIUS * (0.9 + Math.random() * 0.1);
        const angle = Math.random() * Math.PI * 2;
        hexPos.push(Math.cos(angle) * r, y, Math.sin(angle) * r);
    }
    hexGeo.setAttribute('position', new THREE.Float32BufferAttribute(hexPos, 3));
    hexGeo.userData = { originalPositions: [...hexPos] };
    const hexs = new THREE.Points(hexGeo, new THREE.PointsMaterial({
        size: 2.2, color: 0xccffff, map: createParticleTexture(ParticleShape.HEX_SNOWFLAKE), transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false,
    }));
    scene.add(hexs);
    hexRef.current = hexs;

    // Ribbon
    const ribbonPoints = [];
    for (let i = 0; i <= 120; i++) {
        const p = i / 120;
        const y = THREE.MathUtils.lerp(-TREE_HEIGHT / 2, TREE_HEIGHT / 2, p);
        const r = THREE.MathUtils.lerp(TREE_RADIUS + 2.5, 1, p);
        const a = p * Math.PI * 2 * 4.5;
        ribbonPoints.push(new THREE.Vector3(Math.cos(a) * r, y, Math.sin(a) * r));
    }
    const ribbonMesh = new THREE.Mesh(
        new THREE.TubeGeometry(new THREE.CatmullRomCurve3(ribbonPoints), 150, 0.25, 6, false),
        new THREE.MeshBasicMaterial({ color: 0xC0C0C0, transparent: true, opacity: 0.7, side: THREE.DoubleSide, blending: THREE.AdditiveBlending })
    );
    scene.add(ribbonMesh);
    ribbonRef.current = ribbonMesh;

    // Star
    const createStarShape = (outerRadius: number, innerRadius: number, points: number) => {
        const shape = new THREE.Shape();
        const step = Math.PI / points;
        shape.moveTo(0, outerRadius);
        for (let i = 0; i < 2 * points; i++) {
            const r = (i % 2 === 1) ? innerRadius : outerRadius;
            const a = i * step;
            shape.lineTo(Math.sin(a) * r, Math.cos(a) * r);
        }
        shape.closePath();
        return shape;
    };
    const starMesh = new THREE.Mesh(
        new THREE.ExtrudeGeometry(createStarShape(2.5, 1.2, 5), { depth: 0.8, bevelEnabled: true, bevelThickness: 0.2, bevelSize: 0.1, bevelSegments: 2 }),
        new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.1, metalness: 0.9, emissive: 0xffffff, emissiveIntensity: 1.0 })
    );
    starMesh.position.set(0, TREE_HEIGHT / 2 + 1.5, 0);
    starMesh.add(new THREE.PointLight(0xffffff, 2, 30));
    scene.add(starMesh);
    starRef.current = starMesh;

    // Lights for Star
    scene.add(new THREE.AmbientLight(0xffffff, 0.5));
    const dLight = new THREE.DirectionalLight(0xffffff, 1);
    dLight.position.set(10, 20, 10);
    scene.add(dLight);

    // Photo Group Container (Content added in next useEffect)
    const photoGroup = new THREE.Group();
    scene.add(photoGroup);
    photosRef.current = photoGroup;

    const handleResize = () => {
      if (!cameraRef.current || !rendererRef.current || !composerRef.current) return;
      cameraRef.current.aspect = window.innerWidth / window.innerHeight;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(window.innerWidth, window.innerHeight);
      composerRef.current.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (rendererRef.current && containerRef.current) {
        containerRef.current.removeChild(rendererRef.current.domElement);
      }
      geometry.dispose();
      material.dispose();
      // Dispose others...
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); 

  // EFFECT: Update Photos when URL list changes
  useEffect(() => {
    if (!photosRef.current) return;
    
    // Clear old photos
    while(photosRef.current.children.length > 0){ 
        const child = photosRef.current.children[0] as THREE.Sprite;
        if(child.material.map) child.material.map.dispose();
        child.material.dispose();
        photosRef.current.remove(child);
    }

    const urls = appState.photoUrls;
    if (!urls || urls.length === 0) return;

    // Use at most 5 photos for the tree
    const count = Math.min(urls.length, 5); 
    // Fallback to PHOTO_COUNT constant if array is small, to distribute evenly, 
    // but here we just distribute however many we have.
    const displayCount = count; 

    const textureLoader = new THREE.TextureLoader();

    for(let i=0; i<displayCount; i++) {
        const y = (i / displayCount) * (TREE_HEIGHT * 0.8) - TREE_HEIGHT/2 + 5;
        const progress = 1 - ((y + TREE_HEIGHT/2) / TREE_HEIGHT);
        const r = progress * TREE_RADIUS + 2; 
        const angle = i * (Math.PI * 2 / 1.618); 

        const x = Math.cos(angle) * r;
        const z = Math.sin(angle) * r;

        const mat = new THREE.SpriteMaterial({ 
          color: 0xffffff,
          transparent: true,
          toneMapped: false // Keep original colors
        });
        const sprite = new THREE.Sprite(mat);
        sprite.position.set(x, y, z);
        
        // Default scale before load
        sprite.scale.set(4, 4, 1);
        sprite.userData = { originalScale: { x: 4, y: 4 } };
        
        const url = urls[i];
        
        textureLoader.load(url, (texture) => {
            texture.colorSpace = THREE.SRGBColorSpace;
            texture.minFilter = THREE.LinearMipmapLinearFilter;
            texture.magFilter = THREE.LinearFilter;
            texture.generateMipmaps = true;

            const imageAspect = texture.image.width / texture.image.height;
            const baseSize = 4.5;
            
            sprite.material.map = texture;
            sprite.material.needsUpdate = true;
            
            const scaleX = baseSize * imageAspect;
            const scaleY = baseSize;
            
            sprite.scale.set(scaleX, scaleY, 1);
            sprite.userData.originalScale = { x: scaleX, y: scaleY };
        });

        photosRef.current.add(sprite);
    }

  }, [appState.photoUrls]);

  // Update Texture Shape
  useEffect(() => {
    if (particleMaterialRef.current) {
      particleMaterialRef.current.map = createParticleTexture(appState.particleShape);
      particleMaterialRef.current.needsUpdate = true;
    }
  }, [appState.particleShape]);

  // Update Color
  useEffect(() => {
    if (particlesRef.current) {
       const colors = particlesRef.current.geometry.attributes.color.array as Float32Array;
       const baseColor = new THREE.Color(appState.particleColor);
       for(let i=0; i<colors.length; i+=3) {
           const mixed = baseColor.clone().lerp(new THREE.Color(0xffffff), Math.random() * 0.4);
           colors[i] = mixed.r;
           colors[i+1] = mixed.g;
           colors[i+2] = mixed.b;
       }
       particlesRef.current.geometry.attributes.color.needsUpdate = true;
    }
  }, [appState.particleColor]);

  // Animation Loop
  useEffect(() => {
    let animationId: number;
    const clock = new THREE.Clock();

    const animate = () => {
      animationId = requestAnimationFrame(animate);
      const time = clock.getElapsedTime();

      // Gesture Logic
      let targetExpansion = 1.0;
      let rotationInput = 0;
      let pinchTarget = 1.0;
      let targetCameraZ = 80;

      if (handData) {
        if (Math.abs(handData.x) > 0.2) rotationInput = handData.x * 0.05;
        if (handData.gesture === GestureType.FIST) targetExpansion = 0.1;
        else if (handData.gesture === GestureType.OPEN_PALM) {
          targetExpansion = 2.2;
          targetCameraZ = 35;
        }
        if (handData.gesture === GestureType.PINCH) pinchTarget = 2.5;
      }

      targetScaleRef.current = THREE.MathUtils.lerp(targetScaleRef.current, targetExpansion, 0.05);
      rotationSpeedRef.current = THREE.MathUtils.lerp(rotationSpeedRef.current, rotationInput + 0.002, 0.05);
      
      if (cameraRef.current) {
        cameraRef.current.position.z = THREE.MathUtils.lerp(cameraRef.current.position.z, targetCameraZ, 0.05);
      }

      // Update Transforms
      if (particlesRef.current) {
        particlesRef.current.rotation.y += rotationSpeedRef.current;
        const positions = particlesRef.current.geometry.attributes.position.array as Float32Array;
        const originalPositions = particlesRef.current.geometry.userData.originalPositions;
        
        for(let i=0; i < positions.length; i+=3) {
            positions[i] = originalPositions[i] * targetScaleRef.current;
            positions[i+2] = originalPositions[i+2] * targetScaleRef.current;
            const drift = Math.sin(time + positions[i+1]) * 0.05;
            positions[i+1] = originalPositions[i+1] - (time * 0.5 % 5) + drift; 
             if (positions[i+1] < -TREE_HEIGHT/2) positions[i+1] += TREE_HEIGHT;
        }
        particlesRef.current.geometry.attributes.position.needsUpdate = true;
      }

      // Sync other decorations
      const syncRotation = (obj: THREE.Object3D | null) => {
          if(obj && particlesRef.current) obj.rotation.y = particlesRef.current.rotation.y;
      };
      const syncScale = (obj: THREE.Points | THREE.Mesh | null, bob: boolean = false) => {
         if(!obj) return;
         if (obj instanceof THREE.Points) {
            const positions = obj.geometry.attributes.position.array as Float32Array;
            const original = obj.geometry.userData.originalPositions;
            for(let i=0; i < positions.length; i+=3) {
                positions[i] = original[i] * targetScaleRef.current;
                positions[i+2] = original[i+2] * targetScaleRef.current;
                if(bob) positions[i+1] = original[i+1] + Math.sin(time * 3 + i) * 0.1;
            }
            obj.geometry.attributes.position.needsUpdate = true;
         } else {
             obj.scale.set(targetScaleRef.current, 1, targetScaleRef.current);
         }
      };

      syncRotation(giftRef.current); syncScale(giftRef.current, true);
      syncRotation(hexRef.current); syncScale(hexRef.current, true); // Hex slightly diff if needed
      syncRotation(lightsRef.current); syncScale(lightsRef.current);
      if(lightsRef.current) (lightsRef.current.material as THREE.PointsMaterial).opacity = 0.8 + Math.sin(time * 3) * 0.2;
      
      syncRotation(ribbonRef.current); syncScale(ribbonRef.current);

      if (snowRef.current) {
         const positions = snowRef.current.geometry.attributes.position.array as Float32Array;
         for(let i=1; i<positions.length; i+=3) {
             positions[i] -= 0.1; 
             positions[i-1] += Math.sin(time * 1.5 + positions[i] * 0.1) * 0.03;
             if(positions[i] < -40) {
                 positions[i] = 40;
                 positions[i-1] = (Math.random() - 0.5) * 80;
             }
         }
         snowRef.current.geometry.attributes.position.needsUpdate = true;
         snowRef.current.rotation.y -= 0.0005;
      }

      if (starRef.current) {
         starRef.current.rotation.y -= 0.02; 
         starRef.current.rotation.x = Math.sin(time) * 0.1; 
         const mesh = starRef.current as THREE.Mesh;
         (mesh.material as THREE.MeshStandardMaterial).emissiveIntensity = 1.0 + Math.sin(time * 3) * 0.5;
      }

      if (photosRef.current && particlesRef.current) {
          photosRef.current.rotation.y = particlesRef.current.rotation.y;
          photosRef.current.children.forEach(sprite => {
              const originalX = sprite.userData.originalScale?.x || 4;
              const originalY = sprite.userData.originalScale?.y || 4;
              const targetFactor = pinchTarget;
              const targetX = originalX * targetFactor;
              const targetY = originalY * targetFactor;
              const newX = THREE.MathUtils.lerp(sprite.scale.x, targetX, 0.1);
              const newY = THREE.MathUtils.lerp(sprite.scale.y, targetY, 0.1);
              sprite.scale.set(newX, newY, 1);
              sprite.position.y += Math.sin(time * 2) * 0.01;
          });
      }

      if (composerRef.current) composerRef.current.render();
    };

    animate();
    return () => cancelAnimationFrame(animationId);
  }, [handData]); // Dependencies remain simple

  return <div ref={containerRef} className="absolute inset-0 z-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-slate-900 via-[#120524] to-black" />;
};

export default ThreeScene;