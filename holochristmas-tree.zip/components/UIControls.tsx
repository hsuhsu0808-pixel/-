import React, { useRef } from 'react';
import { AppState, GestureType, ParticleShape } from '../types';
import { COLORS } from '../constants';
import { Maximize, Minimize, RotateCcw, Volume2, VolumeX, Hand, Sparkles, Upload, Image as ImageIcon } from 'lucide-react';

interface Props {
  appState: AppState;
  setAppState: React.Dispatch<React.SetStateAction<AppState>>;
  handGesture: GestureType;
  onPhotoUpload?: (files: FileList | null) => void;
}

const UIControls: React.FC<Props> = ({ appState, setAppState, handGesture, onPhotoUpload }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const toggleMusic = () => setAppState(prev => ({ ...prev, isMusicPlaying: !prev.isMusicPlaying }));
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
      setAppState(prev => ({ ...prev, isFullscreen: true }));
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
        setAppState(prev => ({ ...prev, isFullscreen: false }));
      }
    }
  };
  const resetTree = () => {
      setAppState(prev => ({ ...prev, particleShape: ParticleShape.SPARKLE, particleColor: COLORS.primary }));
  };

  const handleUploadClick = () => {
      fileInputRef.current?.click();
  };

  return (
    <div className="absolute top-4 right-4 w-72 bg-black/40 backdrop-blur-md rounded-xl border border-white/10 p-4 text-white shadow-2xl z-20 transition-all duration-300 hover:bg-black/50 max-h-[90vh] overflow-y-auto">
      
      {/* Header */}
      <div className="flex justify-between items-center mb-4 border-b border-white/10 pb-2">
        <h2 className="text-lg font-bold font-['Orbitron'] text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">
          HOLOTREE OS
        </h2>
        <div className="flex gap-2">
           <button onClick={toggleMusic} className="p-1.5 hover:bg-white/20 rounded-full transition">
              {appState.isMusicPlaying ? <Volume2 size={16} /> : <VolumeX size={16} />}
           </button>
           <button onClick={toggleFullscreen} className="p-1.5 hover:bg-white/20 rounded-full transition">
              {appState.isFullscreen ? <Minimize size={16} /> : <Maximize size={16} />}
           </button>
        </div>
      </div>

      {/* Gesture Status */}
      <div className="mb-4 bg-white/5 rounded-lg p-3 flex items-center justify-between border border-white/5">
        <div className="flex items-center gap-2">
            <Hand className={`w-4 h-4 ${handGesture !== GestureType.NONE ? 'text-green-400 animate-pulse' : 'text-gray-500'}`} />
            <span className="text-xs font-mono uppercase tracking-wider text-gray-300">Detected:</span>
        </div>
        <span className={`text-xs font-bold font-mono px-2 py-0.5 rounded ${handGesture !== GestureType.NONE ? 'bg-blue-500/20 text-blue-300' : 'text-gray-500'}`}>
            {handGesture}
        </span>
      </div>

      {/* Controls */}
      <div className="space-y-4">
        
        {/* Shape Selector */}
        <div>
          <label className="text-xs text-gray-400 mb-1 block flex items-center gap-1">
             <Sparkles size={12} /> Particles
          </label>
          <select 
            value={appState.particleShape}
            onChange={(e) => setAppState(prev => ({...prev, particleShape: e.target.value as ParticleShape}))}
            className="w-full bg-black/50 border border-white/20 rounded px-2 py-1.5 text-sm focus:outline-none focus:border-purple-500 transition-colors"
          >
            {Object.values(ParticleShape).map(shape => (
                <option key={shape} value={shape}>{shape}</option>
            ))}
          </select>
        </div>

        {/* Color Picker */}
        <div>
          <label className="text-xs text-gray-400 mb-1 block">Theme Color</label>
          <div className="flex gap-2">
             <input 
               type="color" 
               value={appState.particleColor}
               onChange={(e) => setAppState(prev => ({...prev, particleColor: e.target.value}))}
               className="h-8 w-8 rounded cursor-pointer bg-transparent border-none" 
             />
             <div className="text-xs text-gray-500 self-center font-mono">{appState.particleColor}</div>
          </div>
        </div>
        
        {/* Photo Upload */}
        <div>
            <label className="text-xs text-gray-400 mb-1 block flex items-center gap-1">
                <ImageIcon size={12} /> Decor Photos (5)
            </label>
            <input 
                type="file" 
                ref={fileInputRef} 
                onChange={(e) => onPhotoUpload && onPhotoUpload(e.target.files)} 
                multiple 
                accept="image/*" 
                className="hidden" 
            />
            <button 
                onClick={handleUploadClick}
                className="w-full py-2 bg-blue-600/30 hover:bg-blue-600/50 text-blue-100 rounded-lg flex items-center justify-center gap-2 text-sm transition-all border border-blue-500/30 active:scale-95"
            >
                <Upload size={14} /> Upload Photos
            </button>
            <p className="text-[9px] text-gray-500 mt-1 text-center">Select 5 photos to display.</p>
        </div>

        {/* Reset */}
        <button 
            onClick={resetTree}
            className="w-full mt-2 py-2 bg-white/10 hover:bg-white/20 rounded-lg flex items-center justify-center gap-2 text-sm transition-all border border-white/5 active:scale-95"
        >
            <RotateCcw size={14} /> Reset System
        </button>

      </div>

      {/* Hint Footer */}
      <div className="mt-4 pt-2 border-t border-white/10 text-[10px] text-gray-500 text-center leading-tight">
        Try: Fist to close, Open to bloom, Pinch photos, Move hand to rotate.
      </div>

    </div>
  );
};

export default UIControls;