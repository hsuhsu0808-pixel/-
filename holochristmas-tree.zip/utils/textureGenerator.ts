import * as THREE from 'three';
import { ParticleShape } from '../types';

export const createParticleTexture = (shape: ParticleShape): THREE.Texture => {
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  
  if (!ctx) return new THREE.Texture();

  ctx.clearRect(0, 0, size, size);
  ctx.fillStyle = '#FFFFFF';
  ctx.shadowBlur = 10;
  ctx.shadowColor = '#FFFFFF';

  const center = size / 2;
  const radius = size / 3;

  ctx.save();
  ctx.translate(center, center);

  switch (shape) {
    case ParticleShape.CIRCLE:
      ctx.beginPath();
      ctx.arc(0, 0, radius, 0, Math.PI * 2);
      ctx.fill();
      break;

    case ParticleShape.STAR:
      ctx.beginPath();
      for (let i = 0; i < 5; i++) {
        ctx.lineTo(Math.cos((18 + i * 72) * Math.PI / 180) * radius,
                   -Math.sin((18 + i * 72) * Math.PI / 180) * radius);
        ctx.lineTo(Math.cos((54 + i * 72) * Math.PI / 180) * radius * 0.4,
                   -Math.sin((54 + i * 72) * Math.PI / 180) * radius * 0.4);
      }
      ctx.closePath();
      ctx.fill();
      break;

    case ParticleShape.HEART:
      const topCurveHeight = radius * 0.8;
      ctx.beginPath();
      ctx.moveTo(0, topCurveHeight);
      ctx.bezierCurveTo(0, 0, -radius * 1.5, 0, -radius * 1.5, topCurveHeight);
      ctx.bezierCurveTo(-radius * 1.5, -radius * 0.5, 0, -radius * 1.5, 0, -radius * 1.5);
      ctx.bezierCurveTo(0, -radius * 1.5, radius * 1.5, -radius * 0.5, radius * 1.5, topCurveHeight);
      ctx.bezierCurveTo(radius * 1.5, 0, 0, 0, 0, topCurveHeight);
      ctx.closePath();
      // Rotate heart to be upright
      ctx.rotate(Math.PI); 
      ctx.fill();
      break;

    case ParticleShape.SNOWFLAKE:
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 4;
      ctx.lineCap = 'round';
      for (let i = 0; i < 6; i++) {
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(0, -radius);
        ctx.stroke();
        // Add little branches
        ctx.beginPath();
        ctx.moveTo(0, -radius * 0.6);
        ctx.lineTo(radius * 0.2, -radius * 0.8);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(0, -radius * 0.6);
        ctx.lineTo(-radius * 0.2, -radius * 0.8);
        ctx.stroke();
        ctx.rotate(Math.PI / 3);
      }
      break;

    case ParticleShape.HEX_SNOWFLAKE:
      // A filled hexagonal crystal plate
      ctx.beginPath();
      for (let i = 0; i < 6; i++) {
        const angle = i * Math.PI / 3;
        ctx.lineTo(Math.cos(angle) * radius, Math.sin(angle) * radius);
      }
      ctx.closePath();
      ctx.lineWidth = 3;
      ctx.strokeStyle = '#FFFFFF';
      ctx.stroke();
      
      // Inner detail
      ctx.beginPath();
      for (let i = 0; i < 6; i++) {
        const angle = i * Math.PI / 3;
        ctx.moveTo(0, 0);
        ctx.lineTo(Math.cos(angle) * (radius * 0.7), Math.sin(angle) * (radius * 0.7));
      }
      ctx.stroke();
      
      // Small dots at vertices
      ctx.fillStyle = '#FFFFFF';
      for (let i = 0; i < 6; i++) {
         const angle = i * Math.PI / 3;
         ctx.beginPath();
         ctx.arc(Math.cos(angle) * radius, Math.sin(angle) * radius, 3, 0, Math.PI*2);
         ctx.fill();
      }
      break;

    case ParticleShape.GIFT_BOX:
      // Draw 4 squares to form a gift box with a cross ribbon gap
      const boxSize = radius * 0.8;
      const gap = 4; // Ribbon width (negative space)
      
      ctx.fillStyle = '#FFFFFF';
      
      // Top Left Quadrant
      ctx.fillRect(-boxSize, -boxSize, boxSize - gap, boxSize - gap);
      // Top Right
      ctx.fillRect(gap, -boxSize, boxSize - gap, boxSize - gap);
      // Bottom Left
      ctx.fillRect(-boxSize, gap, boxSize - gap, boxSize - gap);
      // Bottom Right
      ctx.fillRect(gap, gap, boxSize - gap, boxSize - gap);

      // Bow on top
      ctx.beginPath();
      ctx.moveTo(0, -boxSize);
      ctx.bezierCurveTo(-boxSize/2, -boxSize*1.5, -boxSize, -boxSize, 0, -boxSize);
      ctx.bezierCurveTo(boxSize, -boxSize, boxSize/2, -boxSize*1.5, 0, -boxSize);
      ctx.fill();
      break;
      
    case ParticleShape.SPARKLE:
    default:
       // Cross shape with glow
       ctx.beginPath();
       const gradient = ctx.createRadialGradient(0,0, 0, 0,0, radius);
       gradient.addColorStop(0, 'rgba(255,255,255,1)');
       gradient.addColorStop(1, 'rgba(255,255,255,0)');
       ctx.fillStyle = gradient;
       ctx.arc(0, 0, radius, 0, Math.PI * 2);
       ctx.fill();
       
       ctx.fillStyle = '#FFF';
       ctx.fillRect(-radius, -2, radius * 2, 4);
       ctx.fillRect(-2, -radius, 4, radius * 2);
       break;
  }

  ctx.restore();

  const texture = new THREE.CanvasTexture(canvas);
  texture.needsUpdate = true;
  return texture;
};